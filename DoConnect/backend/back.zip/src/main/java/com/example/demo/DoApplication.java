package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DoApplication {

	public static void main(String[] args) {
		SpringApplication.run(DoApplication.class, args);
	}

}

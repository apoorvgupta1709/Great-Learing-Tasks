export interface Question {
  id: Number;
  userName: String;
  userEmail: String;
  answer: String;
  answered: boolean;
  question: String;
}
